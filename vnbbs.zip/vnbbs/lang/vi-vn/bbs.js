var lang = {
	'warning': 'Cảnh báo',
	'tips_title': 'Gợi ý:',
	'confirm': 'Xác nhận',
	'confirm_title': 'Vui lòng xác nhận các thông tin sau:',
	'confirm_delete': 'Xác nhận xóa?',
	'close': 'Đóng',
	'yes': 'Có',
	'no': 'Không',
	'open': 'Mở',
	// hook lang_vi_vn_bbs_js.htm
};