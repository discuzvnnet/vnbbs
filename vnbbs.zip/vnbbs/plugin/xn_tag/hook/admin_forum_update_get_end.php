
		
		$tag_maxid = tag_maxid();
		$tag_cate_maxid = tag_cate_maxid();
		$tagcatelist = tag_cate_find_by_fid($_fid);
		