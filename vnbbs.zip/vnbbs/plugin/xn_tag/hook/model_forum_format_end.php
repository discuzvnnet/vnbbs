

	forum_format_tag($forum);
	
