if($post['deleted']) {
	$post['classname'] .= ' deleted';
}