		ipaccess_inc($longip, 'attachs');
		ipaccess_inc($longip, 'attachsizes', $filesize);