<?php
exit;

'haya_post_like' => 'Thích bài viết',

'haya_post_like_reply' => 'Trích dẫn',

'haya_post_like_notice' => 'Thích',

'haya_post_like_setting_open_thread' => 'Thích chủ đề ',
'haya_post_like_setting_open_thread_tip' => 'Kích hoạt lượt thích trên các chủ đề bài viết.',
'haya_post_like_setting_list_show_likes' => 'Danh sách thích',
'haya_post_like_setting_list_show_likes_tip' => 'Có hiển thị số lượt thích của chủ đề trong danh sách hay không',

'haya_post_like_setting_thread_like_position' => 'Vị trí chủ đề thích',
'haya_post_like_setting_thread_like_position_tip' => 'Đặt vị trí của lượt thích chủ đề.',
'haya_post_like_setting_thread_like_position_update_before' => 'Trước khi chỉnh sửa',
'haya_post_like_setting_thread_like_position_message_after' => 'Sau thông tin chủ đề',

'haya_post_like_setting_open_post' => 'Thích trả lời',
'haya_post_like_setting_open_post_tip' => '启用对回复的点赞功能。',
'haya_post_like_setting_post_like_position' => '回复点赞位置',
'haya_post_like_setting_post_like_position_tip' => '设置回复点赞的位置。',
'haya_post_like_setting_post_like_position_create_date_after' => '创建时间后',
'haya_post_like_setting_post_like_position_quote_before' => '引用前',
'haya_post_like_setting_post_like_position_filelist_after' => '回复内容下',
'haya_post_like_setting_post_like_position_filelist_after_right' => '回复内容下-右侧',
'haya_post_like_setting_post_like_position_filelist_after_media' => '回复内容下-自适应',

'haya_post_like_setting_post_like_loved_color' => '回复已赞颜色',
'haya_post_like_setting_post_like_loved_color_secondary' => '灰色',
'haya_post_like_setting_post_like_loved_color_primary' => '蓝色',
'haya_post_like_setting_post_like_loved_color_danger' => 'Đỏ',
'haya_post_like_setting_post_like_loved_color_warning' => 'Cam',
'haya_post_like_setting_post_like_loved_color_success' => 'Xanh lá',
'haya_post_like_setting_post_like_loved_color_info' => 'Xanh biển',
'haya_post_like_setting_post_like_loved_color_dark' => 'Tối',
'haya_post_like_setting_post_like_loved_color_light' => 'Sáng',
'haya_post_like_setting_post_like_loved_color_white' => 'Trắng',
'haya_post_like_setting_post_like_loved_color_tip' => 'Đặt màu của lượt thích trả lời',

'haya_post_like_setting_open_hot_like' => 'Câu trả lời phổ biến',
'haya_post_like_setting_open_hot_like_tip' => 'Có bật các câu trả lời phổ biến hay không. Nếu được bật, các câu trả lời phổ biến sẽ được hiển thị trước danh sách trả lời.',
'haya_post_like_setting_hot_like_post_low_count' => 'Trả lời lượt thích',
'haya_post_like_setting_hot_like_post_low_count_tip' => 'Số lượt thích có thể coi là một câu trả lời phổ biến.',
'haya_post_like_setting_hot_like_post_size' => 'Số lượng câu trả lời phổ biến',
'haya_post_like_setting_hot_like_post_size_tip' => 'Số lượng câu trả lời phổ biến tối đa được hiển thị.',
'haya_post_like_setting_hot_like_isfirst' => 'Các câu trả lời phổ biến bao gồm các bài viết chính',
'haya_post_like_setting_hot_like_isfirst_tip' => 'Có đưa bài đăng chính của chủ đề vào các câu trả lời phổ biến hay không, bị tắt theo mặc định.',
'haya_post_like_setting_hot_like_life_time' => 'Thời gian lưu trữ câu trả lời phổ biến',
'haya_post_like_setting_hot_like_life_time_tip' => 'Đặt thời gian lưu vào bộ nhớ đệm của các câu trả lời phổ biến, mặc định là một ngày. Đơn vị: giây. Đặt 0 có nghĩa là không có bộ nhớ đệm.',

'haya_post_like_setting_clear_hot_like' => 'Xóa bộ nhớ đệm của các câu trả lời phổ biến',
'haya_post_like_setting_now_clear_hot_like' => 'Xóa bộ nhớ đệm',
'haya_post_like_setting_no_clear_hot_like' => 'Chưa được xóa',
'haya_post_like_setting_clear_hot_like_tip' => 'Xóa bộ đệm của các câu trả lời phổ biến. Khoảng thời gian mặc định là cập nhật bộ đệm dựa trên “thời gian bộ đệm phản hồi phổ biến”',

'haya_post_like_setting_like_is_delete' => 'Hủy thích',
'haya_post_like_setting_like_is_delete_tip' => 'Có cho phép người dùng bỏ thích bài viết họ thích hay không, được bật theo mặc định.',
'haya_post_like_setting_delete_time' => 'Khoảng thời gian thích',
'haya_post_like_setting_delete_time_tip' => 'Đặt khoảng thời gian giữa các thao tác thích và hủy lượt thích và bật “Hủy lượt thích” để có hiệu lực.',
'haya_post_like_setting_open_my_post_like' => 'Thích kỷ lục',
'haya_post_like_setting_open_my_post_like_tip' => 'Trung tâm cá nhân hiển thị lịch sử tương tự của người dùng, lịch sử này bị tắt theo mặc định',
'haya_post_like_setting_my_post_like_pagesize' => 'Ghi lại số trang',
'haya_post_like_setting_my_post_like_pagesize_tip' => 'Trung tâm cá nhân hiển thị số lượng bản ghi lượt thích của người dùng trên mỗi trang, mặc định là 10',
'haya_post_like_setting_post_like_count_type' => 'Thống kê thời gian thực',
'haya_post_like_setting_post_like_count_type_tip' => 'Nếu bạn gặp vấn đề với dữ liệu lượt thích, vui lòng kích hoạt nó',
'haya_post_like_setting_success_tip' => 'Đã sửa đổi cài đặt thành công',

'haya_post_like_like' => 'Thích',
'haya_post_like_unlike' => 'Hủy thích',
'haya_post_like_has_like' => 'Đã thích',
'haya_post_like_like_count' => 'Số lượt thích',
'haya_post_like_like_post' => 'Thích và trả lời',
'haya_post_like_like_thread' => 'Thích bài đăng này',
'haya_post_like_tip_title' => 'Lời khuyên',
'haya_post_like_login_like_tip' => 'Bạn chỉ có thể thích nó sau khi đăng nhập!',
'haya_post_like_login_like_thread_tip' => 'Bạn chỉ có thể thích bài đăng này sau khi đăng nhập! Nhấp vào <b class="text-primary">OK</b> để đăng nhập',
'haya_post_like_login_like_post_tip' => 'Bạn chỉ có thể thích câu trả lời này sau khi đăng nhập! Nhấp vào <b class="text-primary">OK</b> để đăng nhập',

'haya_post_like_hot_post' => 'Câu trả lời phổ biến',

'haya_post_like_close_thread_tip' => 'Chức năng thích bài viết chưa được kích hoạt!',
'haya_post_like_close_post_tip' => 'Chức năng thích để trả lời chưa được bật!',
'haya_post_like_user_has_like_tip' => 'Bạn đã thích nó rồi!',
'haya_post_like_like_success_tip' => 'Thích thành công!',
'haya_post_like_unlike_success_tip' => 'Hủy lượt thích thành công!',
'haya_post_like_no_unlike_tip' => 'Lượt thích không thể bị hủy!',
'haya_post_like_user_no_like_tip' => 'Bạn vẫn chưa thích nó!',
'haya_post_like_no_fast_like_tip' => 'Xin đừng hủy thích quá nhanh nhé!',
'haya_post_like_like_error_tip' => 'Lỗi truy cập!',

'haya_post_like_my_no_post_like_tip' => 'Không thể truy cập được nữa!',

'haya_post_like_send_notice_for_thread' => 'Đã thích chủ đề của bạn {thread}',
'haya_post_like_send_notice_for_post' => 'Đã thích câu trả lời {post} của bạn trong chủ đề {thread}',

?>