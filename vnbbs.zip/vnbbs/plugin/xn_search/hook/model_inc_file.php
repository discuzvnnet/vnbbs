
APP_PATH.'plugin/xn_search/model/search.func.php',