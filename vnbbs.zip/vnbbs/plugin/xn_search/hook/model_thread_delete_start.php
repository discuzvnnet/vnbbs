<?php exit;
	db_delete('thread_search', array('tid'=>$tid));
?>