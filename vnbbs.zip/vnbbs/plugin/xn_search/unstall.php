<?php

/*
	VNBBS 4.0
	admin/plugin-unstall-xn_search.htm
*/

!defined('DEBUG') AND exit('Forbidden');

?>