	'huux_postlist_sort_asc'=>'正序',
	'huux_postlist_sort_desc'=>'倒序',
	'huux_postlist_all'=>'全部',
	'huux_postlist_author'=>'樓主',