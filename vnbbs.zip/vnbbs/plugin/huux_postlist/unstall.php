<?php

defined('DEBUG') OR exit('Forbidden');

?>
