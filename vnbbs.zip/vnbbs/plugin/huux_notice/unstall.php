<?php

/*
	VNBBS 4.0
*/

!defined('DEBUG') AND exit('Forbidden');


?>